# Jarvis – voice assistant that controls your Android phone

Say **"Jarvis, open YouTube"**, **"Jarvis, call Mom"**, **"Jarvis, set an alarm for 6:30"**,
**"Jarvis, message Rahul on WhatsApp that I'm late"**.

## Talk to it like a friend (Hindi + English)
Say **"Jarvis, aaj bahut boring day tha"** or **"Jarvis, tell me a joke"** and it chats back in your language
(Hindi, English or a Hinglish mix), remembers the last few turns, and can mix chat with phone tasks.
- In the app choose the listening language: **English/Hinglish** (default) or **Hindi**. Restart Jarvis after changing.
- Jarvis speaks Hindi parts with a Hindi voice and English parts with an Indian-English voice.
  If Hindi sounds wrong, install/enable the Hindi voice in Android: Settings > Text-to-speech > Google > Install voice data.
- Chat memory is kept in RAM only and is erased when you turn Jarvis off.

## Locked screen (Vivo V23 5G, Android 14)
**Works while locked:** listening for "Jarvis", chatting, voice replies, alarms, and calls.
**Cannot work while locked:** opening apps, tapping, typing, messaging. Android does not let any app unlock a PIN/pattern/fingerprint lock, and Jarvis deliberately never stores your PIN.
Instead Jarvis says "unlock kar do" and **continues the task automatically as soon as you unlock** (within 2 minutes).
To keep listening with the screen off, finish step 5 in the app (battery settings). Vivo's Funtouch OS kills background apps aggressively, so:
- Settings > Battery > Background power consumption management > Jarvis > Allow high background power consumption
- i Manager > App manager > Autostart > Jarvis ON
- Recent apps > lock the Jarvis card
- Keep the Jarvis notification visible (do not hide it).
Listening all day costs battery. Use **Turn off** in the notification when you do not need it.

## How it works
1. `VoiceService` listens for the wake word "Jarvis" (Android speech recognition) and speaks replies.
2. `Agent` reads the screen through `JarvisAccessibilityService`, asks the AI what to do next, performs it, and repeats (max 15 steps).
3. `Actions` handles direct things: open app, call, compose SMS, alarm, web search.

## Build and install (about 10 minutes)
1. Install **Android Studio** (free) on a computer.
2. **File > Open** and choose this `Jarvis` folder. Let Gradle sync finish (it downloads what it needs).
3. On your phone: **Settings > About phone**, tap *Build number* 7 times, then **Developer options > USB debugging** on.
4. Connect the phone with USB, accept the prompt, press the green **Run** button.

## First-time setup in the app
1. Get a Gemini API key at aistudio.google.com/apikey, paste it in the app, tap **Save key**. (Never put the key in the source code or share it; if it leaks, delete it in AI Studio and make a new one.) The model name defaults to `gemini-3.8-flash`; if Google retires it, Jarvis tries `gemini-3.6-flash`, or you can type another model name.
2. **Grant permissions**.
3. **Open Accessibility settings** > Jarvis > turn on. If it is greyed out: App info > ⋮ menu > **Allow restricted settings**, then try again.
4. **Allow display over other apps** (lets Jarvis open apps from the background).
5. Tap **Start Jarvis**. Try the *Run command* box first (e.g. `open Camera`), then try your voice.

## Safety built in
- Refuses to operate banking/UPI/wallet/password apps and Settings (list in `Config.kt`, edit as needed).
- Passwords and bare OTP-looking numbers are never sent to the AI.
- Asks before deleting, buying, paying, or messaging an unclear recipient.
- Notification buttons: **Stop task** (cancels immediately) and **Turn off**.
- Screen text and your chat go to Google's Gemini API while Jarvis works. On Google's free tier, inputs may be used to improve Google products (check their current terms); a paid/billing-enabled key has stricter data handling. Do not use Jarvis on screens with private info you don't want shared.

## Known limits
- Android may beep when listening restarts on some phones (turn the phone's "notification sound" down).
- Speech recognition uses your phone's default language. Set it to English (India) for best results with "Jarvis".
- Some apps block accessibility taps on certain screens; Jarvis will say it got stuck.
- Battery use is higher while Jarvis is on. Use **Turn off** when not needed.
- The API key is stored privately in the app, not encrypted. Use a key with a spending limit.

## Next upgrades
Offline wake word (Porcupine), better speech (Whisper), Hindi commands, conversation memory, floating mic button.
