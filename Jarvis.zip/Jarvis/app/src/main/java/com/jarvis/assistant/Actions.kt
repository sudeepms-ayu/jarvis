package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/** Phone-level actions that do not need to touch the screen. Each returns a short result for the AI. */
class Actions(private val ctx: Context) {

    private fun launch(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        true
    } catch (e: Exception) {
        false
    }

    private fun has(permission: String) =
        ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED

    fun openApp(name: String): String {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val wanted = name.trim().lowercase()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == wanted }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(wanted) }
            ?: return "No installed app matches \"$name\"."
        val pkg = match.activityInfo.packageName
        if (pkg in Config.BLOCKED_PACKAGES) return "BLOCKED: Jarvis does not operate that app for your safety."
        val intent = pm.getLaunchIntentForPackage(pkg) ?: return "Could not launch $name."
        return if (launch(intent)) "Opened ${match.loadLabel(pm)}." else "Android refused to open $name."
    }

    private fun findNumber(contactOrNumber: String): String? {
        val trimmed = contactOrNumber.trim()
        if (trimmed.replace(Regex("[\\s\\-+()]"), "").all { it.isDigit() } && trimmed.any { it.isDigit() }) return trimmed
        if (!has(android.Manifest.permission.READ_CONTACTS)) return null
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$trimmed%"),
            null
        ) ?: return null
        cursor.use { return if (it.moveToFirst()) it.getString(0) else null }
    }

    fun call(contactOrNumber: String): String {
        if (!has(android.Manifest.permission.CALL_PHONE)) return "Phone permission has not been granted."
        val number = findNumber(contactOrNumber)
            ?: return "Could not find a number for \"$contactOrNumber\" (is Contacts permission granted?)."
        return if (launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))))
            "Calling $contactOrNumber." else "Could not start the call."
    }

    /** Opens the SMS app with the text filled in; the AI then taps Send like a person would. */
    fun composeSms(contactOrNumber: String, text: String): String {
        val number = findNumber(contactOrNumber)
            ?: return "Could not find a number for \"$contactOrNumber\"."
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", text)
        return if (launch(i)) "Message composed to $contactOrNumber. Tap Send to send it." else "No SMS app found."
    }

    fun setAlarm(hour: Int, minute: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(i)) "Alarm set for %02d:%02d.".format(hour, minute) else "Could not set the alarm."
    }

    fun webSearch(query: String): String {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        return if (launch(Intent(Intent.ACTION_VIEW, uri))) "Searching the web for \"$query\"." else "No browser found."
    }
}
