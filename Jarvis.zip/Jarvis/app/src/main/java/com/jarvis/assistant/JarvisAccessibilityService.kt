package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Jarvis's eyes and hands: reads what is on screen and performs taps, typing and scrolling.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
    }

    data class Screen(
        val packageName: String,
        val description: String,
        val nodes: List<AccessibilityNodeInfo>
    )

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- Reading the screen ----------

    fun readScreen(): Screen {
        val root = rootInActiveWindow
            ?: return Screen("", "(screen not available right now)", emptyList())
        val pkg = root.packageName?.toString().orEmpty()
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        walk(root, nodes, sb)
        return Screen(pkg, sb.toString().ifBlank { "(empty screen)" }, nodes)
    }

    private fun walk(n: AccessibilityNodeInfo, nodes: MutableList<AccessibilityNodeInfo>, sb: StringBuilder) {
        if (nodes.size >= 80 || !n.isVisibleToUser) return

        val raw = (n.text ?: n.contentDescription)?.toString()?.trim().orEmpty()
        val useful = n.isClickable || n.isEditable || n.isScrollable || raw.isNotEmpty()
        if (useful) {
            // Privacy: never pass passwords or bare one-time codes to the AI.
            val shown = when {
                n.isPassword -> "[hidden]"
                Regex("^\\d{4,8}$").matches(raw) -> "[number hidden]"
                else -> raw.take(80).replace("\n", " ")
            }
            val flags = buildList {
                if (n.isClickable) add("tap")
                if (n.isEditable) add("input")
                if (n.isScrollable) add("scroll")
                if (n.isChecked) add("checked")
            }.joinToString(",")
            val type = n.className?.toString()?.substringAfterLast('.').orEmpty()
            sb.append("[${nodes.size}] $type \"$shown\" ($flags)\n")
            nodes.add(n)
        }
        for (i in 0 until n.childCount) {
            n.getChild(i)?.let { walk(it, nodes, sb) }
        }
    }

    // ---------- Acting on the screen ----------

    fun tapNode(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        while (cur != null) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
        }
        // Fallback: tap the centre of the node's bounds.
        val r = android.graphics.Rect()
        node.getBoundsInScreen(r)
        return tapXY(r.centerX().toFloat(), r.centerY().toFloat())
    }

    fun typeInto(node: AccessibilityNodeInfo, text: String): Boolean {
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(nodes: List<AccessibilityNodeInfo>, forward: Boolean): Boolean {
        val target = nodes.firstOrNull { it.isScrollable } ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return target.performAction(action)
    }

    fun tapXY(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 60)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
}
