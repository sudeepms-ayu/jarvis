package com.jarvis.assistant

import android.content.Context

/** Stores the API key and model name privately on the phone. */
object Config {
    private const val PREFS = "jarvis_prefs"
    private const val KEY_API = "api_key"
    private const val KEY_MODEL = "model"
    const val DEFAULT_MODEL = "gemini-3.8-flash"

    /** Apps Jarvis refuses to operate: banking, payments, wallets, password managers. */
    val BLOCKED_PACKAGES = setOf(
        "com.google.android.apps.nbu.paisa.user", // Google Pay
        "com.phonepe.app",
        "net.one97.paytm",
        "in.org.npci.upiapp",                      // BHIM
        "com.sbi.SBIFreedomPlus",
        "com.snapwork.hdfc",
        "com.csam.icici.bank.imobile",
        "com.axis.mobile",
        "com.google.android.apps.walletnfcrel",
        "com.paypal.android.p2pmobile",
        "com.bitwarden.mobile",
        "com.x8bit.bitwarden",
        "com.lastpass.lpandroid",
        "com.onepassword.android",
        "com.google.android.apps.authenticator2",
        "com.android.settings"                     // keeps Jarvis from switching off its own permissions
    )

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = prefs(c).getString(KEY_API, "").orEmpty()
    fun setApiKey(c: Context, v: String) = prefs(c).edit().putString(KEY_API, v.trim()).apply()

    /** Language the microphone listens in: "en-IN" (English/Hinglish in Latin letters) or "hi-IN" (Hindi). */
    fun speechLang(c: Context): String = prefs(c).getString("speech_lang", "en-IN").orEmpty()
    fun setSpeechLang(c: Context, v: String) = prefs(c).edit().putString("speech_lang", v).apply()

    fun model(c: Context): String = prefs(c).getString(KEY_MODEL, DEFAULT_MODEL).orEmpty().ifBlank { DEFAULT_MODEL }
    fun setModel(c: Context, v: String) = prefs(c).edit().putString(KEY_MODEL, v.trim()).apply()
}
