package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** One simple setup screen. Built in code so there are no layout files to get wrong. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, pad / 2, 0, pad / 4)
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false
            setOnClickListener { onClick() }
        }

        root.addView(label("Jarvis", 30f, true))
        root.addView(label("Voice assistant for your phone. Finish the 5 setup steps, then press Start."))

        status = label("", 14f).apply { setTextColor(Color.DKGRAY) }
        root.addView(status)

        root.addView(label("1. Gemini API key (get one free at aistudio.google.com/apikey)", 16f, true))
        keyField = EditText(this).apply {
            hint = "Paste your Gemini API key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Config.apiKey(this@MainActivity))
        }
        root.addView(keyField)
        modelField = EditText(this).apply {
            hint = "Gemini model (default ${Config.DEFAULT_MODEL})"
            setText(Config.model(this@MainActivity))
        }
        root.addView(modelField)
        root.addView(button("Save key") {
            Config.setApiKey(this, keyField.text.toString())
            Config.setModel(this, modelField.text.toString())
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            refresh()
        })

        root.addView(label("2. Permissions (microphone, contacts, calls, notifications)", 16f, true))
        root.addView(button("Grant permissions") {
            val perms = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            )
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            requestPermissions(perms.toTypedArray(), 1)
        })

        root.addView(label("3. Screen control: find Jarvis, switch it on. If it is greyed out, open App info > ⋮ menu > Allow restricted settings first.", 14f))
        root.addView(button("Open Accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("Open App info (for restricted settings)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        root.addView(label("4. Allow Jarvis to open apps while in the background", 16f, true))
        root.addView(button("Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })

        root.addView(label("5. Keep Jarvis alive with screen off / locked (needed on Vivo)", 16f, true))
        root.addView(label("Tap the button and choose Allow. Then on your Vivo: Settings > Battery > Background power consumption management > Jarvis > Allow high background power consumption. Also: i Manager > App manager > Autostart > Jarvis ON. Finally open Recent apps and lock the Jarvis card.", 13f))
        root.addView(button("Ignore battery optimisation for Jarvis") {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        })

        root.addView(label("Language Jarvis listens in", 16f, true))
        root.addView(label("English/Hinglish works best for mixed talk. Switch to Hindi if you speak mostly Hindi. Jarvis replies in whatever language you use. Restart Jarvis after changing.", 13f))
        lateinit var langBtn: Button
        fun langText() = if (Config.speechLang(this) == "hi-IN") "Listening: हिन्दी (tap to switch)" else "Listening: English / Hinglish (tap to switch)"
        langBtn = button(langText()) {
            val next = if (Config.speechLang(this) == "hi-IN") "en-IN" else "hi-IN"
            Config.setSpeechLang(this, next)
            langBtn.text = langText()
        }
        root.addView(langBtn)

        root.addView(label("Run", 16f, true))
        root.addView(button("▶  Start Jarvis") {
            if (Config.apiKey(this).isBlank()) {
                Toast.makeText(this, "Save your API key first", Toast.LENGTH_LONG).show()
            } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Grant the microphone permission first (step 2)", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, VoiceService::class.java))
                Toast.makeText(this, "Say: Jarvis, open YouTube  —  or just: Jarvis, kaisa hai?", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(button("■  Stop Jarvis") {
            stopService(Intent(this, VoiceService::class.java))
        })

        root.addView(label("Test without speaking", 16f, true))
        val cmd = EditText(this).apply { hint = "e.g. open Camera" }
        root.addView(cmd)
        root.addView(button("Run command") {
            val text = cmd.text.toString().trim()
            if (text.isNotEmpty() && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Grant the microphone permission first (step 2)", Toast.LENGTH_LONG).show()
            } else if (text.isNotEmpty()) {
                startForegroundService(
                    Intent(this, VoiceService::class.java)
                        .setAction(VoiceService.ACTION_RUN_TEXT)
                        .putExtra(VoiceService.EXTRA_TEXT, text)
                )
            }
        })

        val scroll = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            addView(root)
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(code: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, permissions, results)
        refresh()
    }

    private fun refresh() {
        fun ok(b: Boolean) = if (b) "✅" else "❌"
        val key = Config.apiKey(this).isNotBlank()
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val acc = JarvisAccessibilityService.instance != null
        val overlay = Settings.canDrawOverlays(this)
        val battery = getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        status.text = "${ok(key)} Gemini key    ${ok(mic)} Microphone\n${ok(acc)} Screen control    ${ok(overlay)} Open apps in background\n${ok(battery)} Stays alive when locked"
    }
}
