package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.PowerManager
import androidx.core.content.ContextCompat
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Always-on listener. Say "Jarvis, <command>" (or just "Jarvis", wait for "Yes?", then the command).
 * Runs as a foreground service so Android keeps it alive; the notification has a Stop button.
 */
class VoiceService : Service() {

    companion object {
        const val ACTION_RUN_TEXT = "com.jarvis.assistant.RUN_TEXT"
        const val ACTION_STOP_TASK = "com.jarvis.assistant.STOP_TASK"
        const val ACTION_QUIT = "com.jarvis.assistant.QUIT"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL = "jarvis_listening"
        private const val NOTIF_ID = 1
        private val WAKE_WORDS = listOf("jarvis", "जार्विस", "जारविस", "जर्विस", "जार्विश", "जरविस")
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var taskJob: Job? = null

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speaking = false
    private var listening = false
    private var awaitingCommand = false
    private var destroyed = false

    private lateinit var agent: Agent

    private var wakeLock: PowerManager.WakeLock? = null
    private var pendingUnlock: String? = null

    /** When the user unlocks the phone, finish the task that was waiting for it. */
    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val cmd = pendingUnlock ?: return
            pendingUnlock = null
            main.postDelayed({ runCommand(cmd) }, 1500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startInForeground()

        // Keep the CPU awake so listening continues with the screen off / phone locked.
        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Jarvis::Listening")
            .apply { setReferenceCounted(false); acquire() }
        ContextCompat.registerReceiver(
            this, unlockReceiver, IntentFilter(Intent.ACTION_USER_PRESENT), ContextCompat.RECEIVER_NOT_EXPORTED
        )

        agent = Agent(this) { say(it) }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) = afterSpeech()
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) = afterSpeech()
                })
                ttsReady = true
            }
        }
        main.post { startListening() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RUN_TEXT -> intent.getStringExtra(EXTRA_TEXT)?.let { runCommand(it) }
            ACTION_STOP_TASK -> {
                taskJob?.cancel()
                say("Stopped.")
            }
            ACTION_QUIT -> {
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        destroyed = true
        try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
        wakeLock?.let { if (it.isHeld) it.release() }
        taskJob?.cancel()
        scope.cancel()
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------- Commands ----------

    private fun runCommand(text: String) {
        taskJob?.cancel()
        stopListening()
        taskJob = scope.launch {
            try {
                agent.run(text)
            } catch (e: kotlinx.coroutines.CancellationException) {
                // user stopped the task
            } catch (e: Exception) {
                say("Something went wrong.")
            } finally {
                agent.waitingForUnlock?.let { waiting ->
                    pendingUnlock = waiting
                    agent.waitingForUnlock = null
                    // Forget it if the user does not unlock within 2 minutes.
                    main.postDelayed({ if (pendingUnlock == waiting) pendingUnlock = null }, 120_000)
                }
                main.post { if (!speaking) startListening() }
            }
        }
    }

    private fun handleHeard(heard: String) {
        val text = heard.trim()
        if (text.isEmpty()) return

        if (awaitingCommand) {
            awaitingCommand = false
            runCommand(text)
            return
        }

        val lower = text.lowercase()
        // The recogniser may write the name in Latin or Devanagari letters.
        val hit = WAKE_WORDS.mapNotNull { w -> lower.indexOf(w).takeIf { it >= 0 }?.let { it to w.length } }
            .minByOrNull { it.first } ?: return
        val command = text.substring(hit.first + hit.second).trim(' ', ',', '.', '!', '।')
        if (command.isEmpty()) {
            awaitingCommand = true
            say("Yes?")
        } else {
            runCommand(command)
        }
    }

    // ---------- Speech output ----------

    private fun say(text: String) {
        main.post {
            if (!ttsReady) return@post
            stopListening()
            speaking = true
            // Hindi voice for Devanagari text, Indian-English voice otherwise.
            val hasHindi = text.any { it in 'ऀ'..'ॿ' }
            tts?.language = if (hasHindi) Locale("hi", "IN") else Locale("en", "IN")
            tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "jarvis-${System.nanoTime()}")
        }
    }

    private fun afterSpeech() {
        main.post {
            if (tts?.isSpeaking == true) return@post   // more queued
            speaking = false
            if (taskJob?.isActive != true) startListening()
        }
    }

    // ---------- Speech input ----------

    private fun startListening() {
        if (destroyed || listening || speaking) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(listener)
            }
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Config.speechLang(this@VoiceService))
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        listening = true
        recognizer?.startListening(i)
    }

    private fun stopListening() {
        listening = false
        recognizer?.cancel()
    }

    private fun restartSoon(delayMs: Long = 400) {
        listening = false
        main.postDelayed({ startListening() }, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) return
            // "No speech" while waiting after "Yes?" -> give up and go back to wake-word mode.
            if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                awaitingCommand = false
            }
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                recognizer?.destroy(); recognizer = null
            }
            if (!speaking && taskJob?.isActive != true) restartSoon(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
            else listening = false
        }

        override fun onResults(results: Bundle?) {
            listening = false
            val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            handleHeard(heard)
            if (!speaking && taskJob?.isActive != true) restartSoon()
        }
    }

    // ---------- Notification ----------

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Jarvis listening", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun startInForeground() {
        fun pi(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, VoiceService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis is listening")
            .setContentText("Say \"Jarvis\" followed by a command")
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(0, "Stop task", pi(ACTION_STOP_TASK, 1)).build())
            .addAction(Notification.Action.Builder(0, "Turn off", pi(ACTION_QUIT, 2)).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }
}
